import React from 'react';
import { Text, View } from 'react-native';
import { styles } from './styles';
export default function Desejos() {
  return (
    <View style={styles.container}>
      <Text>DESEJOS</Text>
     
    </View>
  );
}

